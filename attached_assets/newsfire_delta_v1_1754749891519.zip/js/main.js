// Инициализация мини‑теста с пояснениями
(function(){
  const root = document.getElementById('quizRoot');
  if(!root) return;

  const questions = [
    {
      q: 'Что означает первая буква в методе PASS?',
      options: ['Press', 'Pull', 'Point'],
      correct: 1,
      explain: 'P — Pull: выдернуть чек‑кольцо перед использованием.'
    },
    {
      q: 'Куда целиться соплом при тушении?',
      options: ['В центр пламени', 'В основание очага', 'Над пламенем'],
      correct: 1,
      explain: 'Целиться нужно в основание очага возгорания.'
    }
  ];

  let i = 0, score = 0;
  render();

  function render(){
    if(i >= questions.length){
      root.innerHTML = `<p>Готово! Ваш результат: <b>${score}/${questions.length}</b>.</p>`;
      return;
    }
    const {q, options} = questions[i];
    root.innerHTML = `
      <p><b>Вопрос ${i+1}:</b> ${q}</p>
      <div>
        ${options.map((opt, idx) => `<button class="btn" data-idx="${idx}">${opt}</button>`).join('')}
      </div>
      <div id="explain" style="margin-top:8px;color:#94a3b8"></div>
    `;

    root.querySelectorAll('button[data-idx]').forEach(btn => btn.addEventListener('click', () => {
      const {correct, explain} = questions[i];
      const idx = Number(btn.getAttribute('data-idx'));
      const ok = idx === correct;
      if(ok) score++;
      const ex = root.querySelector('#explain');
      ex.textContent = (ok ? 'Верно. ' : 'Неверно. ') + explain;
      setTimeout(() => { i++; render(); }, 900);
    }));
  }
})();

// Регистрация SW
if('serviceWorker' in navigator){
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(console.warn);
  });
}
