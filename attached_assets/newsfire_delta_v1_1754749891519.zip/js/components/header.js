(function(){
  const el = document.getElementById('site-header');
  if(!el) return;
  el.innerHTML = `
    <nav class="nav" role="navigation" aria-label="Основная навигация">
      <div class="logo" aria-label="NewsFire — на главную">
        <a href="/">NewsFire</a>
      </div>
      <div class="nav-links">
        <a href="#games">Тренажёры</a>
        <a href="#tests">Тесты</a>
        <a href="#tools">Инструменты</a>
      </div>
    </nav>
  `;
})();
