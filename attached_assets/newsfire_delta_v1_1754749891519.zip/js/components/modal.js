(function(){
  const openers = document.querySelectorAll('[data-open-modal]');
  const closers = document.querySelectorAll('[data-close-modal]');

  openers.forEach(btn => btn.addEventListener('click', () => {
    const id = btn.getAttribute('data-open-modal');
    const modal = document.getElementById(id);
    if(modal){ modal.hidden = false; modal.querySelector('.modal-content')?.focus(); }
  }));

  closers.forEach(btn => btn.addEventListener('click', () => {
    const modal = btn.closest('.modal');
    if(modal) modal.hidden = true;
  }));

  document.addEventListener('keydown', e => {
    if(e.key === 'Escape'){
      document.querySelectorAll('.modal').forEach(m => m.hidden = true);
    }
  });
})();
