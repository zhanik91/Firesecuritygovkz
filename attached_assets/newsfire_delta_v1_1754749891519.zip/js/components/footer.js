(function(){
  const el = document.getElementById('site-footer');
  if(!el) return;
  const year = new Date().getFullYear();
  el.innerHTML = `
    <div class="container">
      <p>© ${year} NewsFire. Обучение и инструменты по пожарной безопасности.</p>
    </div>
  `;
})();
